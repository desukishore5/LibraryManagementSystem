package library.management.system;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;


public class ReadMe extends JFrame{
    private JPanel contentpane;
    public static void main(String args[]){
        new ReadMe().setVisible(true);
    }
    public ReadMe(){
        super("Read Me - library management system");
        setBounds(500, 250, 700, 500);
        
        contentpane = new JPanel();
        setContentPane(contentpane);
        contentpane.setLayout(null);
        
        JLabel l3=new JLabel("LIBRARY");
        l3.setForeground(Color.red);
        l3.setFont(new Font("Trebuchet MS",Font.BOLD, 34));
        l3.setBounds(160, 40, 150, 55);
        contentpane.add(l3);
        
        JLabel l4=new JLabel("MANAGEMENT SYSTEM");
        l4.setForeground(Color.red);
        l4.setFont(new Font("Trebuchet MS",Font.BOLD, 34));
        l4.setBounds(70, 90, 405, 40);
        contentpane.add(l4);
        
        JLabel l5=new JLabel("K-1");
        l5.setForeground(Color.red);
        l5.setFont(new Font("Trebuchet MS",Font.BOLD, 25));
        l5.setBounds(105, 140, 100, 21);
        contentpane.add(l5);
        
        JLabel l6=new JLabel("CODE DEVELOPED BY --- KITTY");
        l6.setForeground(Color.red);
        l6.setFont(new Font("Trebuchet MS",Font.BOLD, 30));
        l6.setBounds(70, 198, 600, 35);
        contentpane.add(l6);
        
        JTextArea l7=new JTextArea("WE DONE THIS!");
        l7.setBounds(70, 260, 600, 200);
        l7.setFont(new Font("Trebuchet MS",Font.BOLD, 50));
        contentpane.add(l7);
        
        contentpane.setBackground(Color.white);
        
        
        
        
        
        
        
        
        
    }
}
